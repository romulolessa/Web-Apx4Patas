Animated SVG Image Slider
=========

A simple, responsive carousel with animated SVG paths used as transition effects.

[Article on CodyHouse](http://codyhouse.co/gem/animated-svg-image-slider/)

[Demo](http://codyhouse.co/demo/animated-svg-image-slider/index.html)

Images: [Unsplash](https://unsplash.com/)
 
[Terms](http://codyhouse.co/terms/)
